var script = document.createElement("SCRIPT");
script.src = "https://lb123658.github.io/dark.mode/mode.js";
document.body.appendChild(script);
